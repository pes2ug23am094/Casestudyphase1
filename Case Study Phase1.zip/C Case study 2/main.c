#include <head.h>
#include <function.c>

float total_bill = 0;
int main()
{
    Customer customers[50];
    Product products[] = {
        {"Product1", 10.00, 20}, 
        {"Product2", 20.00, 15},
        {"Product3", 15.00, 25}};
    int num_customers = 0;
    int num_products = sizeof(products) / sizeof(products[0]);
    int choice;

    do
    {
        printf("\n===== Customer Billing System =====\n");
        printf("1. Add Customer\n");
        printf("2. Modify Customer Details\n");
        printf("3. Generate Bill\n");
        printf("4. Display Customers\n");
        printf("5. View Product Stock\n");
        printf("6. Apply Discount\n");
        printf("7. View Product Details\n");
        printf("8. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            addCustomer(customers, &num_customers);
            break;
        case 2:
            modifyCustomer(customers, num_customers);
            break;
        case 3:
            generateBill(customers, num_customers, products, num_products);
            break;
        case 4:
            displayCustomers(customers, num_customers);
            break;
        case 5:
            viewProductStock(products, num_products);
            break;
        case 6:
            applyDiscount(&total_bill);
            break;
        case 7:
            viewProductDetails(products, num_products);
            break;
        case 8:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 8);

    return 0;
}