#include <head.h>
float total_bill = 0;
void addCustomer(Customer *customers, int *num_customers)
{
    Customer new_customer;
    printf("Enter customer first name: ");
    scanf("%s", new_customer.first_name);
    printf("Enter customer last name: ");
    scanf("%s", new_customer.last_name);
    printf("Enter customer ID: ");
    scanf("%d", &new_customer.id);
    new_customer.total_amount = 0;
    customers[*num_customers] = new_customer;
    (*num_customers)++;
    printf("Customer added successfully.\n");
}
void modifyCustomer(Customer *customers, int num_customers)
{
    int customer_id, choice;
    printf("Enter customer ID to modify details: ");
    scanf("%d", &customer_id);

    for (int i = 0; i < num_customers; i++)
    {
        if (customers[i].id == customer_id)
        {
            printf("Customer found. What do you want to modify?\n");
            printf("1. First Name\n");
            printf("2. Last Name\n");
            printf("3. ID\n");
            printf("Enter your choice: ");
            scanf("%d", &choice);
            switch (choice)
            {
            case 1:
                printf("Enter new first name: ");
                scanf("%s", customers[i].first_name);
                printf("First name updated successfully.\n");
                break;
            case 2:
                printf("Enter new last name: ");
                scanf("%s", customers[i].last_name);
                printf("Last name updated successfully.\n");
                break;
            case 3:
                printf("Enter new ID: ");
                scanf("%d", &customers[i].id);
                printf("ID updated successfully.\n");
                break;
            default:
                printf("Invalid choice.\n");
            }
            return;
        }
    }
    printf("Customer not found.\n");
}

void generateBill(Customer *customers, int num_customers, Product *products, int num_products)
{
    int customer_id, product_index, quantity;
    float total_bill = 0; 
    printf("Enter customer ID: ");
    scanf("%d", &customer_id);

    for (int i = 0; i < num_customers; i++)
    {
        if (customers[i].id == customer_id)
        {
            printf("Customer: %s %s\n", customers[i].first_name, customers[i].last_name);
            printf("Products Available:\n");
            for (int j = 0; j < num_products; j++)
            {
                printf("%d. %s - $%.2f (Quantity: %d)\n", j + 1, products[j].name, products[j].price, products[j].quantity);
            }
            do
            {
                printf("Enter product index (1 to %d) (-1 to stop): ", num_products);
                scanf("%d", &product_index);
                if (product_index >= 1 && product_index <= num_products)
                {
                    printf("Enter quantity: ");
                    scanf("%d", &quantity);
                    if (quantity > 0 && quantity <= products[product_index - 1].quantity)
                    {
                        total_bill += products[product_index - 1].price * quantity; // Corrected calculation
                        products[product_index - 1].quantity -= quantity;
                    }
                    else
                    {
                        printf("Invalid quantity or not enough stock.\n");
                    }
                }
            } while (product_index != -1);
            customers[i].total_amount += total_bill;
            printf("Total bill: %.2f\n", total_bill);
            printf("Bill generated successfully.\n");
            return;
        }
    }
    printf("Customer not found.\n");
}


void displayCustomers(Customer *customers, int num_customers)
{
    if (num_customers == 0)
    {
        printf("No customers to display.\n");
        return;
    }
    printf("===== Customers =====\n");
    for (int i = 0; i < num_customers; i++)
    {
        printf("Name: %s %s, ID: %d, Total Amount: %.2f\n", customers[i].first_name, customers[i].last_name, customers[i].id, customers[i].total_amount);
    }
}

void viewProductStock(Product *products, int num_products)
{
    printf("===== Product Stock =====\n");
    for (int i = 0; i < num_products; i++)
    {
        printf("Product: %s, Quantity: %d\n", products[i].name, products[i].quantity);
    }
}

void applyDiscount(float *total_bill)
{
    float discount;
    printf("Enter discount percentage: ");
    scanf("%f", &discount);
    *total_bill -= (*total_bill * discount / 100);
    printf("Discount applied successfully.\n");
}

void viewProductDetails(Product *products, int num_products)
{
    printf("===== Product Details =====\n");
    for (int i = 0; i < num_products; i++)
    {
        printf("Product: %s\n", products[i].name);
        printf("Price: $%.2f\n", products[i].price);
        printf("Quantity: %d\n", products[i].quantity);
    }
}
